// O app é montado via RouterProvider em main.tsx
// Este arquivo existe por convenção
export {}
